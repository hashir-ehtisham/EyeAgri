#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QStackedWidget>
#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>

void fadeTransition(QStackedWidget *stack, int newIndex) {
    QWidget *current = stack->currentWidget();
    QWidget *next = stack->widget(newIndex);

    QGraphicsOpacityEffect *outEffect = new QGraphicsOpacityEffect(current);
    current->setGraphicsEffect(outEffect);

    QPropertyAnimation *fadeOut = new QPropertyAnimation(outEffect, "opacity");
    fadeOut->setDuration(200);
    fadeOut->setStartValue(1);
    fadeOut->setEndValue(0);

    QObject::connect(fadeOut, &QPropertyAnimation::finished, [=]() {
        stack->setCurrentIndex(newIndex);

        QGraphicsOpacityEffect *inEffect = new QGraphicsOpacityEffect(next);
        next->setGraphicsEffect(inEffect);

        QPropertyAnimation *fadeIn = new QPropertyAnimation(inEffect, "opacity");
        fadeIn->setDuration(200);
        fadeIn->setStartValue(0);
        fadeIn->setEndValue(1);

        fadeIn->start(QAbstractAnimation::DeleteWhenStopped);
    });

    fadeOut->start(QAbstractAnimation::DeleteWhenStopped);
}

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);

    QStackedWidget *stack = new QStackedWidget();

    // ================= MAIN PAGE =================
    QWidget *mainPage = new QWidget();
    QVBoxLayout *layout = new QVBoxLayout(mainPage);
    layout->setContentsMargins(40, 25, 40, 25);
    layout->setSpacing(0);

    QHBoxLayout *header = new QHBoxLayout();
    header->setContentsMargins(0, 0, 0, 0);

    QVBoxLayout *logoBlock = new QVBoxLayout();
    logoBlock->setSpacing(0);
    logoBlock->setContentsMargins(0, 0, 0, 0);

    QLabel *logo = new QLabel("EyeAgri");
    logo->setStyleSheet(
        "font-size: 90px;"
        "font-weight: 800;"
        "color: #3b2a1a;"
        "font-family: 'Georgia';"
        );
    logo->setFixedHeight(110);
    logo->setAlignment(Qt::AlignLeft | Qt::AlignVCenter);

    QHBoxLayout *taglineRow = new QHBoxLayout();
    taglineRow->setContentsMargins(0, 25, 0, 0);
    taglineRow->setSpacing(0);

    QLabel *taglineSpacer = new QLabel();
    taglineSpacer->setFixedWidth(310);

    QLabel *tagline = new QLabel("The Disease Your Eyes Miss. Ours Won't.");
    tagline->setAlignment(Qt::AlignLeft);
    tagline->setStyleSheet(
        "font-size: 20px;"
        "font-style: italic;"
        "color: #6b4f2a;"
        "font-family: 'Segoe UI';"
        "letter-spacing: 0.4px;"
        );

    taglineRow->addWidget(taglineSpacer);
    taglineRow->addWidget(tagline);
    taglineRow->addStretch();

    logoBlock->addWidget(logo);
    logoBlock->addLayout(taglineRow);

    header->addLayout(logoBlock);
    header->addStretch();

    layout->addLayout(header);
    layout->addStretch(1);

    QLabel *title = new QLabel("EyeAgri - AI based Agriculture Management");
    title->setAlignment(Qt::AlignCenter);
    title->setStyleSheet(
        "font-size: 62px;"
        "font-weight: 700;"
        "color: #3b2a1a;"
        "font-family: 'Georgia';"
        );
    title->setWordWrap(true);

    QLabel *subtitle = new QLabel("Smarter farming through AI-powered analysis and chat assistance");
    subtitle->setAlignment(Qt::AlignCenter);
    subtitle->setStyleSheet("color:#6b4f2a; font-size:32px;");

    // BUTTONS with visible text labels
    QPushButton *btn1 = new QPushButton("🌿  Image Analysis");
    QPushButton *btn2 = new QPushButton("💬  Chat with EyeAgri");
    QPushButton *btn3 = new QPushButton("📊  Data Logging");
    btn1->setObjectName("mainBtn");
    btn2->setObjectName("mainBtn");
    btn3->setObjectName("mainBtn");
    btn1->setFixedSize(280, 52);
    btn2->setFixedSize(280, 52);
    btn3->setFixedSize(280, 52);

    QVBoxLayout *btnLayout = new QVBoxLayout();
    btnLayout->setSpacing(30);
    btnLayout->addWidget(btn3, 0, Qt::AlignCenter);
    btnLayout->addWidget(btn1, 0, Qt::AlignCenter);
    btnLayout->addWidget(btn2, 0, Qt::AlignCenter);

    layout->addWidget(title);
    layout->addSpacing(40);
    layout->addWidget(subtitle);
    layout->addSpacing(80);
    layout->addLayout(btnLayout);
    layout->addStretch(1);

    // ================= PAGE 1 =================
    QWidget *page1 = new QWidget();
    QVBoxLayout *p1 = new QVBoxLayout(page1);
    QHBoxLayout *topBar1 = new QHBoxLayout();
    QPushButton *back1 = new QPushButton("← Back to Home");
    back1->setObjectName("backBtn");
    topBar1->addWidget(back1);
    topBar1->addStretch();
    QLabel *p1Title = new QLabel("Image Analysis");
    p1Title->setAlignment(Qt::AlignCenter);
    p1Title->setStyleSheet("font-size:34px; font-weight:700; color:#3b2a1a;");
    QLabel *p1Desc = new QLabel("Upload crop images and detect diseases using AI.");
    p1Desc->setAlignment(Qt::AlignCenter);
    p1Desc->setStyleSheet("font-size:16px; color:#6b4f2a;");
    p1->addLayout(topBar1);
    p1->addStretch();
    p1->addWidget(p1Title);
    p1->addWidget(p1Desc);
    p1->addStretch();

    // ================= PAGE 2 =================
    QWidget *page2 = new QWidget();
    QVBoxLayout *p2 = new QVBoxLayout(page2);
    QHBoxLayout *topBar2 = new QHBoxLayout();
    QPushButton *back2 = new QPushButton("← Back to Home");
    back2->setObjectName("backBtn");
    topBar2->addWidget(back2);
    topBar2->addStretch();
    QLabel *p2Title = new QLabel("Chat with EyeAgri");
    p2Title->setAlignment(Qt::AlignCenter);
    p2Title->setStyleSheet("font-size:34px; font-weight:700; color:#3b2a1a;");
    QLabel *p2Desc = new QLabel("Ask questions and get smart farming advice.");
    p2Desc->setAlignment(Qt::AlignCenter);
    p2Desc->setStyleSheet("font-size:16px; color:#6b4f2a;");
    p2->addLayout(topBar2);
    p2->addStretch();
    p2->addWidget(p2Title);
    p2->addWidget(p2Desc);
    p2->addStretch();

    // ================= PAGE 3 =================
    QWidget *page3 = new QWidget();
    QVBoxLayout *p3 = new QVBoxLayout(page3);
    QHBoxLayout *topBar3 = new QHBoxLayout();
    QPushButton *back3 = new QPushButton("← Back to Home");
    back3->setObjectName("backBtn");
    topBar3->addWidget(back3);
    topBar3->addStretch();
    QLabel *p3Title = new QLabel("Data Logging");
    p3Title->setAlignment(Qt::AlignCenter);
    p3Title->setStyleSheet("font-size:34px; font-weight:700; color:#3b2a1a;");
    QLabel *p3Desc = new QLabel("Track and log crop health data over time.");
    p3Desc->setAlignment(Qt::AlignCenter);
    p3Desc->setStyleSheet("font-size:16px; color:#6b4f2a;");
    p3->addLayout(topBar3);
    p3->addStretch();
    p3->addWidget(p3Title);
    p3->addWidget(p3Desc);
    p3->addStretch();

    stack->addWidget(mainPage);
    stack->addWidget(page1);
    stack->addWidget(page2);
    stack->addWidget(page3);

    QObject::connect(btn1, &QPushButton::clicked, [=]() { fadeTransition(stack, 1); });
    QObject::connect(btn2, &QPushButton::clicked, [=]() { fadeTransition(stack, 2); });
    QObject::connect(btn3, &QPushButton::clicked, [=]() { fadeTransition(stack, 3); });
    QObject::connect(back1, &QPushButton::clicked, [=]() { fadeTransition(stack, 0); });
    QObject::connect(back2, &QPushButton::clicked, [=]() { fadeTransition(stack, 0); });
    QObject::connect(back3, &QPushButton::clicked, [=]() { fadeTransition(stack, 0); });

    app.setStyleSheet(R"(
        QWidget {
            font-family: 'Segoe UI';
            background: qlineargradient(
                x1:0, y1:0, x2:1, y2:1,
                stop:0 #f5e6c8,
                stop:0.5 #e8d5a3,
                stop:1 #c8b87a
            );
        }

        QPushButton#mainBtn {
            padding: 10px 18px;
            border-radius: 12px;
            border: 2px solid #4a7c3f;
            background-color: #d4a853;
            color: #2c1a0e;
            font-size: 15px;
            font-weight: 600;
            transition: background-color 0.3s;
        }

        QPushButton#mainBtn:hover {
            background-color: #4a7c3f;
            color: #f5e6c8;
            border: 2px solid #2d5a27;
        }

        QPushButton#mainBtn:pressed {
            background-color: #2d5a27;
            color: #f5e6c8;
        }

        QPushButton#backBtn {
            background-color: #4a7c3f;
            color: #f5e6c8;
            padding: 10px 14px;
            border-radius: 8px;
            font-weight: 600;
            border: none;
        }

        QPushButton#backBtn:hover {
            background-color: #2d5a27;
        }
    )");

    stack->resize(900, 550);
    stack->show();

    return app.exec();
}